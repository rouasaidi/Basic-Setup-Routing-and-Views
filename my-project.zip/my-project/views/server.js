const express = require('express');
const app = express();
const routes = require('./routes');

app.set('view engine', 'ejs');
app.set('views' ,__dirname + '/views');
app.use('/', routes);

const port = 3000; // You can change this to any desired port number
app.listen(port,() => {
  console.log('server is running on port ${port}');
});
