// Sample route
app.get('/', (req, res) => {
    res.send('Hello, this is the homepage!');
  });
  
  // Sample route with parameters
  app.get('/user/:id', (req, res) => {
    const userId = req.params.id;
    res.send(`User ID: ${userId}`);
  });
  
  // Catch-all route for handling undefined routes
  app.use((req, res) => {
    res.status(404).send('Page not found');
  });
  
  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
  const express = require('express');
  const router = express.Router();
  
  router.get('/', (req, res) => {
    res.send('Hello, this is the homepage!');
  });
  
  router.get('/users', (req, res) => {
    // Retrieve and send a list of users from the database or any data source
    const users = ['John', 'Jane', 'Mike'];
    res.json(users);
  });
  
  router.post('/user', (req, res) => {
    // Handle the incoming POST data (e.g., create a new user)
    const { name, email } = req.body;
    // Save user data or perform other operations
    res.send(`User created: ${name}, ${email}`);
  });
  
  router.get('/user/:id', (req, res) => {
    const userId = req.params.id;
    // Retrieve user data from the database using userId and send it as a response
    res.send(`User ID: ${userId}`);
  });
  
  router.use((req, res) => {
    res.status(404).send('Page not found');
  });
  
  const app = express();
  app.use('/api', router);